package com.mybook.dto;

import lombok.Data;

@Data
public class QABoardDTO {
	private int boardId;
	private String userid;
	private String subject;
	private String content;
	private String regdate;
	private String status;
	
}
