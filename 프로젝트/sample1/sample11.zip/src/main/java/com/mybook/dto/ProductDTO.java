package com.mybook.dto;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
//@Component
public class ProductDTO {
	private int productId;
	private String productName;
	private int productPrice;
	private int productDiscountPrice;
	private String productDes;
	private MultipartFile uploadFile;
	private String productImg;
	private String productPages;
	private String productIsbn;
	private String productWriter;
	private int sales;
	private String categoryCode;
}
