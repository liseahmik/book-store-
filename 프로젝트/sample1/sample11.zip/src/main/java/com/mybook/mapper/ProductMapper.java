package com.mybook.mapper;

import java.util.HashMap;
import java.util.List;

import com.mybook.dto.CartDTO;
import com.mybook.dto.CartListDTO;
import com.mybook.dto.FavDTO;
import com.mybook.dto.FavListDTO;
import com.mybook.dto.OrderDTO;
import com.mybook.dto.OrderDetailsDTO;
import com.mybook.dto.ProductCategoryDTO;
import com.mybook.dto.ProductDTO;
import com.mybook.dto.ReviewDTO;
import com.mybook.dto.orderProductDTO;

public interface ProductMapper {
	
	//��ǰ��ü��ȸ
	public List<ProductDTO> productAllList(HashMap<String, Object> hm);
	
	//��ǰ��ȸ
	public List<ProductDTO> productList(HashMap<String, Object> hm);
	
	//��ǰ �󼼺���
	public ProductDTO productView(int productId);
	
	//���� �ۼ�
	public void reviewRegister(ReviewDTO review);
	
	//���� ��ȸ
	public List<ReviewDTO> reviewList(HashMap<String, Object> hm);

	//īƮ ���
	public void addCart(CartDTO cart);

	//īƮ ����Ʈ
	public List<CartListDTO> cartList(String userid);

	//īƮ ����
	public void cartDelete(CartDTO cart);

	public void addOrder(OrderDTO order);

	public void addOrderDetails(OrderDetailsDTO orderDetails);

	public CartListDTO findByCartId(int cartId);

	public void cartAllDelete(String userid);

	public List<OrderDTO> orderList(String userid);

	public List<OrderDTO> orderAllList(HashMap<String, Object> hm);

	public OrderDTO orderView(String orderId);

	public List<orderProductDTO> orderProduct(String orderId);

	public int cartSize(String userid);

	public void cartDeleteOrder(HashMap<String, Object> hm);

	public void cartDelete2(CartDTO cart);

	public void addFav(FavDTO fav);

	public List<FavListDTO> favList(String userid);

	public void favDelete(int favId);

	public int findProductId(int cartId);

	public void deleteReview(int reviewId);

	public int getOrderCount(HashMap<String, Object> hm);

	public int reviewCheck(ReviewDTO review);

	public int cartCheck(CartDTO cart);

	public int favCheck(FavDTO fav);

	public int[] getReviewStar(int productId);

	public int getReviewCount(int productId);

	public int getCategoryCount(String categoryCode);

	public int getProductAllCount(HashMap<String, Object> hm);

	public String getOrderTitle(String orderId);

	public List<OrderDetailsDTO> getOrderDetails(String orderId);

	public void addSales(HashMap<String, Object> hm);

	public CartDTO getCart(int cartId);

	public void cartDeleteByCartId(int cartId);

	public List<ProductDTO> getBestSeller();

	public List<ProductDTO> getLatestProducts();

	public ProductCategoryDTO productCategory(int productId);

	public int[] getTotalAmount(String userid);

	public void orderDetailsDelete(String orderId);

	public void orderDelete(String orderId);


}
