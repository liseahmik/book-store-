package com.mybook.dto;

import lombok.Data;

@Data
public class orderProductDTO {
	private OrderDetailsDTO orderDetails;
	private ProductDTO product; 

}
