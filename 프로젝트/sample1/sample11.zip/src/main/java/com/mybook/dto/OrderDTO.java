package com.mybook.dto;

import java.util.Date;

import lombok.Data;

@Data
public class OrderDTO {
	private String orderId;
	private String userid;
	private String status; 
	private String orderName;
	private String orderAddr1;
	private String orderAddr2;
	private String orderAddr3;
	private String orderPhone;
	private int totalAmount;
	private String payment;
	private String orderDate;
	
	
	private String orderTitle; 
	private String tracking;

}

