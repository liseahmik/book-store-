package com.mybook.dto;

import java.util.List;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
//@Component
public class CartDTO {
	private int cartId;
	private String userid;
	private int productId;
	private int qty;
	private String regdate;
	
//	private List<ProductDTO> productList;
//	private List<MemberDTO> userList;

}
