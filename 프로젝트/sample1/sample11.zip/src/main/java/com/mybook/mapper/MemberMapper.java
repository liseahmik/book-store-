package com.mybook.mapper;

import java.util.HashMap;
import java.util.List;

import com.mybook.dto.AuthDTO;
import com.mybook.dto.MemberDTO;
import com.mybook.dto.QABoardDTO;


public interface MemberMapper {
	public MemberDTO read(String userid);
	
	//member join
	public void memberJoin(MemberDTO member);
	
	//auth join
	public void authJoin(AuthDTO auth);
	
	//ȸ������
	public MemberDTO findById(String userid);
	
	//����
	public void update(MemberDTO member);
	
	//Ż��
	public void memberDelete(String userid);
	public void authDelete(String userid);
	
	//���̵� �ߺ�üũ
	public int idDuplChk(String userid);
	
	//��ü��
	public int count(HashMap<String, Object> hm);
	
	//����Ʈ
	public List<MemberDTO> findAll(HashMap<String, Object> hm);

	public String getUserName(String userid);

	public String getProfile(String userid);

	public void setBronze(String userid);

	public void setSilver(String userid);

	public void setGold(String userid);

	public void setPlatinum(String userid);

	public String[] getUserid();



}
