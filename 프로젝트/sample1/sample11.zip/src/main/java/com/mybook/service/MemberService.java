package com.mybook.service;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mybook.dto.AuthDTO;
import com.mybook.dto.MemberDTO;
import com.mybook.dto.QABoardDTO;
import com.mybook.repository.MemberRepository;


@Service
public class MemberService {
	@Autowired
	private MemberRepository memberRepository;
	@Autowired
	private PasswordEncoder pwencoder;
	

	
	@Transactional
	public void join(MemberDTO member,AuthDTO auth) {
		//��й�ȣ ��ȣȭ
		//member.getUserpw(); //��ȣȭ��
		member.setUserpass(pwencoder.encode(member.getUserpass()));
		memberRepository.userJoin(member);
		memberRepository.userAuth(auth);
	}
	
	//ȸ������
	public MemberDTO findById(String userid) {
		return memberRepository.findById(userid);
	}
	
	@Transactional
	public void update(MemberDTO member) {
		member.setUserpass(pwencoder.encode(member.getUserpass()));
		memberRepository.update(member);
	}
	
	@Transactional
	public void delete(String userid) {
		memberRepository.memberDelete(userid);
		memberRepository.authDelete(userid);
	}
	
	// �ߺ� ���̵� üũ
	public int idDuplChk(String userid) {
		return memberRepository.idDuplChk(userid);
	}
	
	public int getCount(HashMap<String, Object> hm) {
		return memberRepository.getCount(hm);
	}
	
	public List<MemberDTO> findAll(HashMap<String, Object> hm) {
		return memberRepository.findAll(hm);
	}

	public String getUserName(String userid) {
		return memberRepository.getUserName(userid);
	}

	public String getProfile(String userid) {
		return memberRepository.getProfile(userid);
	}

	public void setBronze(String userid) {
		memberRepository.setBronze(userid);
		
	}

	public void setSilver(String userid) {
		memberRepository.setSilver(userid);
		
	}

	public void setGold(String userid) {
		memberRepository.setGold(userid);
		
	}

	public void setPlatinum(String userid) {
		memberRepository.setPlatinum(userid);
		
	}

	public String[] getUserid() {
		return memberRepository.getUserid();
	}



}
