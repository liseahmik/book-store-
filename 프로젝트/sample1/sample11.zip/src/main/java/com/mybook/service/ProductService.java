package com.mybook.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import com.mybook.dto.CartDTO;
import com.mybook.dto.CartListDTO;
import com.mybook.dto.FavDTO;
import com.mybook.dto.FavListDTO;
import com.mybook.dto.OrderDTO;
import com.mybook.dto.OrderDetailsDTO;
import com.mybook.dto.ProductCategoryDTO;
import com.mybook.dto.ProductDTO;
import com.mybook.dto.ReviewDTO;
import com.mybook.dto.orderProductDTO;
import com.mybook.repository.ProductRepository;

@Service
public class ProductService {
	@Autowired
	private ProductRepository productRepository;
	
	//��ǰ��ü��ȸ
	public List<ProductDTO> productAllList(HashMap<String, Object> hm){
		return productRepository.productAllList(hm);
	}
	
	//��ǰ��ȸ
	public List<ProductDTO> productList(HashMap<String, Object> hm){
		return productRepository.productList(hm);
	}
	
	//��ǰ �󼼺���
	public ProductDTO productView(int productId) {
		return productRepository.productView(productId);
	}
	
	//���� �ۼ�
	public void reviewRegister(ReviewDTO review) {
		productRepository.reviewRegister(review);
	}
	
	//���� ��ȸ
	public List<ReviewDTO> reviewList(HashMap<String, Object> hm){
		return productRepository.reviewList(hm);
	}

	//īƮ ���
	public void addCart(CartDTO cart) {
		productRepository.addCart(cart);		
	}

	//īƮ ����Ʈ
	public List<CartListDTO> cartList(String userid) {
		return productRepository.cartList(userid);
	}

	//īƮ ����
	public void cartDelete(CartDTO cart) {
		productRepository.cartDelete(cart);		
	}

	public void addOrder(OrderDTO order) {
		productRepository.addOrder(order);		
	}

	public void addOrderDetails(OrderDetailsDTO orderDetails) {
		productRepository.addOrderDetails(orderDetails);
	}

	public CartListDTO findByCartId(int cartId) {
		return productRepository.findByCartId(cartId);
	}

	public void cartAllDelete(String userid) {
		productRepository.cartAllDelete(userid);
		
	}

	public List<OrderDTO> orderList(String userid) {
		return productRepository.orderList(userid);
	}

	public List<OrderDTO> orderAllList(HashMap<String, Object> hm) {
		return productRepository.orderAllList(hm);
	}

	public OrderDTO orderView(String orderId) {
		return productRepository.orderView(orderId);
	}

	public List<orderProductDTO> orderProduct(String orderId) {
		return productRepository.orderProduct(orderId);
	}

	public int cartSize(String userid) {
		return productRepository.cartSize(userid);
	}

	public void cartDeleteOrder(HashMap<String, Object> hm) {
		productRepository.cartDeleteOrder(hm);		
	}

	public void cartDelete2(CartDTO cart) {
		productRepository.cartDelete2(cart);
		
	}

	public void addFav(FavDTO fav) {
		productRepository.addFav(fav);
		
	}

	public List<FavListDTO> favList(String userid) {
		return productRepository.favList(userid);
	}

	public void favDelete(int favId) {
		productRepository.favDelete(favId);
		
	}

	public int findProductId(int cartId) {
		return productRepository.findProductId(cartId);
	}

	public void deleteReview(int reviewId) {
		productRepository.deleteReview(reviewId);
		
	}

	public int getOrderCount(HashMap<String, Object> hm) {
		return productRepository.getOrderCount(hm);
	}

	public int reviewCheck(ReviewDTO review) {
		return productRepository.reviewCheck(review);
	}

	public int cartCheck(CartDTO cart) {
		return productRepository.cartCheck(cart);
	}

	public int favCheck(FavDTO fav) {
		return productRepository.favCheck(fav);
	}

	//���� ����
	public int[] getReviewStar(int productId) {
		return productRepository.getReviewStar(productId);
	}

	//���� ��ü ����
	public int getReviewCount(int productId) {
		return productRepository.getReviewCount(productId);
	}

	//ī�װ����� ��ü ����
	public int getCategoryCount(String categoryCode) {
		return productRepository.getCategoryCount(categoryCode);
	}

	//��ǰ ��ü ����
	public int getProductAllCount(HashMap<String, Object> hm) {
		return productRepository.getProductAllCount(hm);
	}

	public String getOrderTitle(String orderId) {
		return productRepository.getOrderTitle(orderId);
	}

	public List<OrderDetailsDTO> getOrderDetails(String orderId) {
		return productRepository.getOrderDetails(orderId);
	}

	//��ۿϷ�->�Ǹŷ� ����
	public void addSales(HashMap<String, Object> hm) {
		productRepository.addSales(hm);
		
	}

	public CartDTO getCart(int cartId) {
		return productRepository.getCart(cartId);
	}

	public void cartDeleteByCartId(int cartId) {
		productRepository.cartDeleteByCartId(cartId);		
	}

	public List<ProductDTO> getBestSeller() {
		return productRepository.getBestSeller();
	}

	public List<ProductDTO> getLatestProducts() {
		return productRepository.getLatestProducts();
	}

	//product+category join
	public ProductCategoryDTO productCategory(int productId) {
		return productRepository.productCategory(productId);
	}

	public int[] getTotalAmount(String userid) {
		return productRepository.getTotalAmount(userid);
	}

	public void orderDetailsDelete(String orderId) {
		productRepository.orderDetailsDelete(orderId);
		
	}

	public void orderDelete(String orderId) {
		productRepository.orderDelete(orderId);
		
	}






}
