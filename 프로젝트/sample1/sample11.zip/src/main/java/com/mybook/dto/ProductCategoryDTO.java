package com.mybook.dto;

import lombok.Data;

@Data
public class ProductCategoryDTO {
	private ProductDTO product;
	private CategoryDTO category;

}
