package com.mybook.dto;

import lombok.Data;

@Data
public class OrderDetailsDTO {
	private int detailsId;
	private String orderId;
	private int productId;
	private int qty;
	
	private String userid; 
}
