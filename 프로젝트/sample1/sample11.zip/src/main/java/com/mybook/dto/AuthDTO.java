package com.mybook.dto;

import lombok.Data;

@Data
public class AuthDTO {
	private String userid;
	private String auth;

}
