package com.mybook.dto;

import java.util.List;


import lombok.Data;

@Data
public class MemberDTO {
	private String userid;
	private String userpass;
	private String username;
	private String userphone;
	private String useremail;
	private String useraddr1;
	private String useraddr2;
	private String useraddr3;
	private String regdate;
	private String profile;
	private String grade;
	private int mileage;
	private List<AuthDTO> authList;

}
