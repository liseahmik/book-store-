package com.mybook.dto;

import lombok.Data;

@Data
public class QACommentDTO {
	private int commentId;
	private String content;
	private String regdate;
	private int boardId;

}
