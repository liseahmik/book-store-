package com.mybook.dto;

import lombok.Data;

@Data
public class CategoryDTO {
	private String categoryName;
	private String categoryCode;
	private String categoryCodeRef; 
}
