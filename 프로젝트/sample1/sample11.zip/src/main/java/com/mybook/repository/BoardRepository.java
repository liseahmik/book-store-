package com.mybook.repository;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mybook.dto.QABoardDTO;
import com.mybook.dto.QACommentDTO;
import com.mybook.mapper.BoardMapper;

@Repository
public class BoardRepository {
	@Autowired
	private BoardMapper boardMapper;

	public void insert(QABoardDTO board) {
		boardMapper.insert(board);
		
	}

	public List<QABoardDTO> qnafindById(String userid) {
		return boardMapper.qnafindById(userid);
	}
	
	public QABoardDTO myqnaView(int boardId) {
		return boardMapper.myqnaView(boardId);
	}

	public List<QABoardDTO> qnaAllList(HashMap<String, Object> hm) {
		return boardMapper.qnaAllList(hm);
	}

	public void qnaComment(QACommentDTO comment) {
		boardMapper.qnaComment(comment);
		
	}

	public void qnaReplied(int boardId) {
		boardMapper.qnaReplied(boardId);
		
	}

	public QACommentDTO commentView(int boardId) {
		return boardMapper.commentView(boardId);
	}

	public int qnaStatus(int boardId) {
		return boardMapper.qnaStatus(boardId);
	}

	public int getQnaCount(HashMap<String, Object> hm) {
		return boardMapper.getQnaCount(hm);
	}

}
