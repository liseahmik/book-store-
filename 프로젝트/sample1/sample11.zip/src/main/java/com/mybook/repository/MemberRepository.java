package com.mybook.repository;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mybook.dto.AuthDTO;
import com.mybook.dto.MemberDTO;
import com.mybook.dto.QABoardDTO;
import com.mybook.mapper.MemberMapper;


@Repository
public class MemberRepository {
	@Autowired
	private MemberMapper memberMapper;
	
	public void userJoin(MemberDTO member) {
		memberMapper.memberJoin(member);
	}
	
	public void userAuth(AuthDTO auth) {
		memberMapper.authJoin(auth);
	}
	
	public MemberDTO findById(String userid) {
		return memberMapper.findById(userid);
	}
	
	public void update(MemberDTO member) {
		memberMapper.update(member);
	}
	
	
	public void memberDelete(String userid) {
		memberMapper.memberDelete(userid);
	}
	
	public void authDelete(String userid) {
		memberMapper.authDelete(userid);
	}
	
	//���̵��ߺ�üũ
	public int idDuplChk(String userid) {
		return memberMapper.idDuplChk(userid);
	}
	
	public int getCount(HashMap<String, Object> hm) {
		return memberMapper.count(hm);
	}
	
	public List<MemberDTO> findAll(HashMap<String, Object> hm) {
		return memberMapper.findAll(hm);
	}

	public String getUserName(String userid) {
		return memberMapper.getUserName(userid);
	}

	public String getProfile(String userid) {
		return memberMapper.getProfile(userid);
	}

	public void setBronze(String userid) {
		memberMapper.setBronze(userid);
		
	}

	public void setSilver(String userid) {
		memberMapper.setSilver(userid);
		
	}

	public void setGold(String userid) {
		memberMapper.setGold(userid);
		
	}

	public void setPlatinum(String userid) {
		memberMapper.setPlatinum(userid);
	}

	public String[] getUserid() {
		return memberMapper.getUserid();
	}




}
