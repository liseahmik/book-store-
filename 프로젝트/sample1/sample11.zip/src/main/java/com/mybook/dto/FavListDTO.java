package com.mybook.dto;

import lombok.Data;

@Data
public class FavListDTO {
	private FavDTO fav;
	private ProductDTO product;

}
