package com.mybook.dto;


import lombok.Data;

@Data
public class CartListDTO {

	private CartDTO cart;
	private ProductDTO product;

}
