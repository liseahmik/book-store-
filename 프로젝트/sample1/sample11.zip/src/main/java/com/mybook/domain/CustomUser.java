package com.mybook.domain;

import java.util.stream.Collectors;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

import com.mybook.dto.MemberDTO;

import lombok.Getter;
import lombok.Setter;


@Getter @Setter
public class CustomUser extends User {
	private MemberDTO member;
	
	public CustomUser(MemberDTO vo) {
		super(vo.getUserid(),vo.getUserpass(),vo.getAuthList().stream().map(auth->new SimpleGrantedAuthority(auth.getAuth())).collect(Collectors.toList())
		);
		this.member=vo;
	}
	

}
