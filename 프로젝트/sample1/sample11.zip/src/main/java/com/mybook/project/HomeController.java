package com.mybook.project;

import java.security.Principal;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mybook.dto.CartListDTO;
import com.mybook.dto.ProductDTO;
import com.mybook.service.ProductService;

import lombok.extern.log4j.Log4j2;

/**
 * Handles requests for the application home page.
 */
@Log4j2
@Controller
public class HomeController {
	@Autowired
	private ProductService pservice;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
//		logger.info("Welcome home! The client locale is {}.", locale);
//		
//		Date date = new Date();
//		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
//		
//		String formattedDate = dateFormat.format(date);
//		model.addAttribute("serverTime", formattedDate);
		
		return "redirect:index";
	}
	
	@GetMapping("customLogin")
	public String loginInput() {
		log.info("customLogin");
		return "member/customLogin";
	}
	

	@GetMapping("customLogout")
	public String logout() {
		return "member/customLogout";
	}
	
	
	@GetMapping("index")
	public void index(Model model) {
		//����Ʈ���� 3��
		List<ProductDTO> list = pservice.getBestSeller();
		model.addAttribute("list",list);
		
		//�ֱٵ�ϻ�ǰ 8��
		List<ProductDTO> latestList = pservice.getLatestProducts();
		model.addAttribute("latestList",latestList);
	}
	
	

	
	//��ٱ��� ���� ��������
	public void CartSize(Principal principal,Model model){
		if(principal != null) {
			String userid = principal.getName();
			int cartSize = pservice.cartSize(userid);
			model.addAttribute("cartSize", cartSize);
		}
		
	}
	
	




	
}
