package com.mybook.dto;

import lombok.Data;

@Data
public class ReviewDTO {
	private int reviewId;
	private String content;
	private String regdate;
	private int rating;
	private String profile; 
	private String userid;
	private int productId;

}
