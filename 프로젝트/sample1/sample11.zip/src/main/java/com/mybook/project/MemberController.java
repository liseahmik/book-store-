package com.mybook.project;



import java.security.Principal;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mybook.dto.AuthDTO;
import com.mybook.dto.MemberDTO;
import com.mybook.dto.OrderDTO;
import com.mybook.dto.orderProductDTO;
import com.mybook.service.MemberService;
import com.mybook.service.ProductService;

@Controller
public class MemberController {
	@Autowired
	private MemberService mservice;
	
	@Autowired
	private ProductService pservice;
	
	@GetMapping("join")
	public String join() {
		return "member/join";
	}
	
	@PostMapping("join")
	public String join(MemberDTO member,AuthDTO auth) {
		auth.setAuth("ROLE_"+auth.getAuth());
	//	System.out.println("auth:"+auth.getAuth());
		mservice.join(member,auth);
		return "member/customLogin";
	}
	
	//ȸ������
	public void findById(String userid) {
		mservice.findById(userid);
	}
	
	
//	@PostMapping("update")
//	public String update(MemberDTO member,HttpSession session) {
//		mservice.update(member);
//		session.invalidate();
//		return "redirect:/";
//	}
	
	//Ż��
	@GetMapping("delete")
	public String delete(Principal principal, HttpServletRequest request, HttpServletResponse response) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	//	mservice.delete(principal.getName());
		String userid = principal.getName();
		mservice.delete(userid);
		if(auth!=null) {
			new SecurityContextLogoutHandler().logout(request,response,auth);
		}
		return "redirect:/";
	}
	
	//���̵� �ߺ� üũ
	@RequestMapping(value = "idDuplChk" , method = RequestMethod.POST)
	@ResponseBody 
	public String idDuplChk(@ModelAttribute MemberDTO member) throws Exception{
	    int result = mservice.idDuplChk(member.getUserid());
	    return String.valueOf(result);
	}
	
	//��й�ȣ üũ
	@RequestMapping(value = "pwCheck", method = RequestMethod.POST)
	@ResponseBody
	public boolean PwCheck(String pw) {		
		
		boolean check = false;	

	//	String pw_chk = "^(?=.*[A-Za-z])(?=.*[0-9])(?=.*[$@$!%*?&`~'\"+=])[A-Za-z[0-9]$@$!%*?&`~'\"+=]{6,18}$";
		String pw_chk = "^(?=.*[A-Za-z])(?=.*[0-9])[A-Za-z[0-9]]{8,}$"; //�ּ� 8��, �ּ� �ϳ��� ���� �� �ϳ��� ����
				
		Pattern pattern_symbol = Pattern.compile(pw_chk);		
		Matcher matcher_symbol = pattern_symbol.matcher(pw);		
		
		if(matcher_symbol.find()) {	
			check = true;
		}		
		return check;
	}
	
	//����������
	@GetMapping("mypage")
	public String mypage(Principal principal,Model model) {
		String userid = principal.getName();
		MemberDTO member = mservice.findById(userid);
		model.addAttribute("member",member);
		
		List<OrderDTO> orderList = pservice.orderList(userid);
		model.addAttribute("orderList",orderList);
	//	System.out.println(orderList);
		return "member/mypage";
	}
	
	
	//����������-�ֹ��󼼺��� 
	@GetMapping("myorderView")
	public String myorderView(Principal principal, String orderId, Model model) {
		String userid = principal.getName();
		MemberDTO member = mservice.findById(userid);
		model.addAttribute("member",member);
		
		OrderDTO order = pservice.orderView(orderId);
		model.addAttribute("order",order);
		List<orderProductDTO> orderProduct = pservice.orderProduct(orderId);
		model.addAttribute("orderProduct",orderProduct);
		return "member/myorderView";
	}
	
	
	
	//����������-ȸ���������� ��������
	@GetMapping("info")
	public String info(Principal principal,Model model) {
		String userid = principal.getName();
		MemberDTO member = mservice.findById(userid);
		model.addAttribute("member",member);
		
		return "member/info";
	}
	
	//ȸ����������
	@PostMapping("infoUpdate")
	public String infoUpdate(MemberDTO member) {
		mservice.update(member);
		return "redirect:info";
	}

	

	



}
