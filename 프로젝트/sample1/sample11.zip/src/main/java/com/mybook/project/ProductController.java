package com.mybook.project;

import java.security.Principal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mybook.dto.CartDTO;
import com.mybook.dto.CartListDTO;
import com.mybook.dto.FavDTO;
import com.mybook.dto.FavListDTO;
import com.mybook.dto.MemberDTO;
import com.mybook.dto.OrderDTO;
import com.mybook.dto.OrderDetailsDTO;
import com.mybook.dto.PageDTO;
import com.mybook.dto.ProductDTO;
import com.mybook.dto.ReviewDTO;
import com.mybook.service.MemberService;
import com.mybook.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	private ProductService pservice;
	
	@Autowired
	private MemberService mservice;
	

	//��ǰ ����Ʈ(��ü)
	@GetMapping("productAllList")
	public String productAllList(Model model, String field, String word, String strPageNum) {
		
		strPageNum = (strPageNum == null) ? "1" : strPageNum ;
		int pageNum = Integer.parseInt(strPageNum);
		HashMap<String, Object> hm = new HashMap<>();
		hm.put("field",field);
		hm.put("word",word);
		
		int totalCount = pservice.getProductAllCount(hm);
		int pageSize= 6;
		int pageBlock= 5;
		int pageCount = (int) Math.ceil((double) totalCount / pageSize);
		int startPage = ((pageNum / pageBlock) - (pageNum % pageBlock == 0 ? 1 : 0)) * pageBlock + 1;
		int endPage = startPage + pageBlock - 1;
		if(endPage > pageCount) {
			endPage = pageCount;
		}
		PageDTO pageDto = new PageDTO();
		pageDto.setPageCount(pageCount);
		pageDto.setPageBlock(pageBlock);
		pageDto.setStartPage(startPage);
		pageDto.setEndPage(endPage);
		pageDto.setTotalCount(totalCount);
		pageDto.setPageNum(pageNum);
		
		int startRow =(pageNum-1)*pageSize;
		hm.put("startRow",startRow);
		hm.put("pageSize", pageSize);
		List<ProductDTO> list = pservice.productAllList(hm);
		
		model.addAttribute("list",list);
		model.addAttribute("count",totalCount);
		model.addAttribute("pageDto",pageDto);
		model.addAttribute("field",field);
		model.addAttribute("word",word);
		model.addAttribute("categoryCode",null); //�Ǵ���Ȯ��
		

		return "product/productList";
	}
	
	
	
	//��ǰ ����Ʈ(ī�װ�����)
	@GetMapping("productList")
	public String productList(Model model, @RequestParam String categoryCode, String strPageNum) {
		strPageNum = (strPageNum == null) ? "1" : strPageNum ;
		int pageNum = Integer.parseInt(strPageNum);
		HashMap<String, Object> hm = new HashMap<>();

		
		int totalCount = pservice.getCategoryCount(categoryCode);
		int pageSize= 6;
		int pageBlock= 5;
		int pageCount = (int) Math.ceil((double) totalCount / pageSize);
		int startPage = ((pageNum / pageBlock) - (pageNum % pageBlock == 0 ? 1 : 0)) * pageBlock + 1;
		int endPage = startPage + pageBlock - 1;
		if(endPage > pageCount) {
			endPage = pageCount;
		}
		PageDTO pageDto = new PageDTO();
		pageDto.setPageCount(pageCount);
		pageDto.setPageBlock(pageBlock);
		pageDto.setStartPage(startPage);
		pageDto.setEndPage(endPage);
		pageDto.setTotalCount(totalCount);
		pageDto.setPageNum(pageNum);
		
		int startRow =(pageNum-1)*pageSize;
		hm.put("startRow",startRow);
		hm.put("pageSize", pageSize);
		hm.put("categoryCode", categoryCode);
		List<ProductDTO> list = pservice.productList(hm);
		
		model.addAttribute("list",list);
		model.addAttribute("count",totalCount);
		model.addAttribute("pageDto",pageDto);
		model.addAttribute("categoryCode",categoryCode); 
		

		return "product/productList";
	}
	

	
	//��ǰ �󼼺���(+���� ����Ʈ)
	@GetMapping("productView")
	public String productView(int productId, Model model, String strPageNum) {
		ProductDTO view = pservice.productView(productId);
		model.addAttribute("view",view);
		

		//��������
		int[] stars = pservice.getReviewStar(productId);
		int count = pservice.getReviewCount(productId);
		int sum = 0;
		int star1 = 0;
		int star2 = 0;
		int star3 = 0;
		int star4 = 0;
		int star5 = 0;
		
		for(int i : stars) {
			sum += i;
			if(i==5) star5 +=1;
			else if(i==4) star4 +=1;
			else if(i==3) star3 +=1;
			else if(i==2) star2 +=1;
			else star1 +=1;
		}
		
		double avg = (double)sum/(double)count;
	//	avg = (Math.round(avg*100)/100);
		if (Double.isNaN(avg)) avg=0;
		String avg1 = String.format("%.1f", avg);
		
		model.addAttribute("avg",avg1);
		model.addAttribute("count",count);
		model.addAttribute("star1",star1);
		model.addAttribute("star2",star2);
		model.addAttribute("star3",star3);
		model.addAttribute("star4",star4);
		model.addAttribute("star5",star5);
		
		//���� ����¡
		strPageNum = (strPageNum == null) ? "1" : strPageNum ;
		int pageNum = Integer.parseInt(strPageNum);
		HashMap<String, Object> hm = new HashMap<>();
		
		int totalCount = pservice.getReviewCount(productId);
		int pageSize= 3;
		int pageBlock= 5;
		int pageCount = (int) Math.ceil((double) totalCount / pageSize);
		int startPage = ((pageNum / pageBlock) - (pageNum % pageBlock == 0 ? 1 : 0)) * pageBlock + 1;
		int endPage = startPage + pageBlock - 1;
		if(endPage > pageCount) {
			endPage = pageCount;
		}
		PageDTO pageDto = new PageDTO();
		pageDto.setPageCount(pageCount);
		pageDto.setPageBlock(pageBlock);
		pageDto.setStartPage(startPage);
		pageDto.setEndPage(endPage);
		pageDto.setTotalCount(totalCount);
		pageDto.setPageNum(pageNum);
		
		int startRow =(pageNum-1)*pageSize;
		hm.put("startRow",startRow);
		hm.put("pageSize", pageSize);
		hm.put("productId", productId);
		List<ReviewDTO> review = pservice.reviewList(hm);
		
		model.addAttribute("review",review);
		model.addAttribute("count",totalCount);
		model.addAttribute("pageDto",pageDto);
		model.addAttribute("productId",productId);

		
		return "product/productView";
	}
	
	
	
	//�����ۼ�
	@ResponseBody
	@PostMapping("reviewRegister")
	public int reviewRegister(ReviewDTO review, Principal principal) {
		int result = 0;
		
		if(principal != null) {
			String userid = principal.getName();
			review.setUserid(userid);
			int reviewCheck = pservice.reviewCheck(review);
			if(reviewCheck==0) {
				review.setProfile(mservice.getProfile(userid));
				pservice.reviewRegister(review);
				result=1;
			}else {
				result=2;
			}
		}
		System.out.println(result);
		return result;
	}
	

	//���� ����
	@ResponseBody
	@GetMapping("deleteReview")
	public void deleteReview(int reviewId,Principal principal) {
		String userid = principal.getName();
		pservice.deleteReview(reviewId);
	}
	

	//īƮ ���
	@ResponseBody
	@PostMapping("addCart")
	public int addCart(CartDTO cart, Principal principal) {
		int result = 0;
		
		if(principal != null) {
			String userid = principal.getName();
			cart.setUserid(userid);
			int cartCheck = pservice.cartCheck(cart);
			if(cartCheck==0) {
				pservice.addCart(cart);
				result=1;
			}else {
				result=2;
			}
		}
		System.out.println(result);
		return result;
	}
	

	//īƮ����Ʈ
	@GetMapping("cartList")
	public String cartList(Model model, Principal principal) {
		if(principal != null) {
			String userid = principal.getName();
			List<CartListDTO> cartList = pservice.cartList(userid);
			model.addAttribute("cartList", cartList);
		}
		return "product/cartList";
	}
	
	
	//īƮ ���� ����
	@ResponseBody
	@PostMapping("cartDelete")
	public void cartDelete(Principal principal, 
			@RequestParam(value="chbox[]") List<String> chArr, CartDTO cart) {
		String userid = principal.getName();
		cart.setUserid(userid);

		int cartId = 0;
		
		for(String i : chArr) {
			cartId = Integer.parseInt(i);
			cart.setCartId(cartId);
			pservice.cartDelete(cart);			
		}
	}
	
	//īƮ ��ü ����
	@ResponseBody
	@GetMapping("cartAllDelete")
	public void cartAllDelete(Principal principal) {
		String userid = principal.getName();
		pservice.cartAllDelete(userid);
	}

	

	//�ֹ��ϱ�
	@PostMapping("orderForm")
	public String orderForm(Model model, Principal principal,HttpServletRequest request) {
		String userid = principal.getName();
		MemberDTO user = mservice.findById(userid);
		model.addAttribute("user",user);
		
		List<CartListDTO> selectArr = new ArrayList<CartListDTO>();
		String[] arr = request.getParameterValues("chBox");
		int cartId =0;
		for(int i=0;i<arr.length; i++) {
			cartId = Integer.parseInt(arr[i]);
			selectArr.add(pservice.findByCartId(cartId));
		}
		
		model.addAttribute("cartList",selectArr);		

		return "product/orderForm";
	}

	


	//�ֹ� �߰�
	@Transactional
	@PostMapping("order")
	public String addOrder(Principal principal, OrderDTO order, HttpServletRequest request) {
		String userid = principal.getName();
		order.setUserid(userid);
		
		Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);
		String ym = year + new DecimalFormat("00").format(cal.get(Calendar.MONTH) + 1);
		String ymd = ym +  new DecimalFormat("00").format(cal.get(Calendar.DATE));
		String subNum = "";
		 
		for(int i = 1; i <= 6; i ++) {
			subNum += (int)(Math.random() * 10);
		}
		 
	    String orderId = ymd + "_" + subNum;
		
	    order.setOrderId(orderId);
	    pservice.addOrder(order);
		
	    String[] arr = request.getParameterValues("cartId");
	    
		int cartId = 0;
		OrderDetailsDTO details = new OrderDetailsDTO();
		
		for(int i=0;i<arr.length; i++) {
			cartId = Integer.parseInt(arr[i]);
			//īƮ����Ʈ -> details
			CartDTO cart = pservice.getCart(cartId);
			details.setProductId(cart.getProductId());
			details.setQty(cart.getQty());
			details.setOrderId(orderId);
			pservice.addOrderDetails(details);
			//īƮ����
			pservice.cartDeleteByCartId(cartId); 			
		}
	    
		
		return "redirect:mypage";
	}
	

	
	
	//������ ���
	@ResponseBody
	@PostMapping("addFav")
	public int addFav(FavDTO fav, Principal principal) {
		int result =0;
		
		if(principal != null) {
			String userid = principal.getName();
			fav.setUserid(userid);
			int favCheck = pservice.favCheck(fav);
			if(favCheck==0) {
				pservice.addFav(fav);
				result = 1;
			}else {
				result=2;
			}
		}
		System.out.println(result);
		return result;
	}
	
	
	//������ ����Ʈ
	@GetMapping("fav")
	public String favList(Model model, Principal principal) {
		if(principal != null) {
			String userid = principal.getName();
			MemberDTO member = mservice.findById(userid);
			model.addAttribute("member",member);

			List<FavListDTO> favList = pservice.favList(userid);
			model.addAttribute("favList", favList);
		}
		return "member/fav";
	}
	
	
	
	//������ ����
	@ResponseBody
	@PostMapping("favDelete")
	public void favDelete(int favId) {
		pservice.favDelete(favId);
	}
	


	//������->��ٱ��� 
	@Transactional
	@ResponseBody
	@PostMapping("cartMove")
	public int cartMove(int favId, CartDTO cart, Principal principal) {
		int result = 0;
		
		if(principal != null) {
			String userid = principal.getName();
			cart.setUserid(userid);
			int cartCheck = pservice.cartCheck(cart);
			if(cartCheck==0) {
				pservice.addCart(cart);
				pservice.favDelete(favId);
				result=1;
			}else {
				result=2;
			}
		}
		System.out.println(result);
		return result;
	}	
	

	
	//��ٱ���->������ (����)
	@Transactional
	@ResponseBody
	@PostMapping("cartFav")
	public int cartFav(Principal principal, 
			@RequestParam(value="chbox[]") List<String> chArr, CartDTO cart, FavDTO fav) {
		String userid = principal.getName();
		cart.setUserid(userid);
		fav.setUserid(userid);

		int result = 0;
		int cartId = 0;
		
		for(String i : chArr) {
			cartId = Integer.parseInt(i);
			cart.setCartId(cartId);
			fav.setProductId(pservice.findProductId(cartId));
			int favCheck = pservice.favCheck(fav);
			if(favCheck==0) {
				pservice.addFav(fav);
				pservice.cartDelete(cart);
				result=1;
			}else {
				result=2;
			}
			if(result==2) break;
		}
		System.out.println(result);
		return result;
	}
	
	
	//īƮ ���� 
	@ResponseBody
	@GetMapping("cartSize")
	public int cartSize(Principal principal) {
		int cartCount =0;
		if(principal != null) {
			String userid = principal.getName();
			cartCount = pservice.cartSize(userid);
		}
		return cartCount;
	}

	
	//�ֹ����
	@GetMapping("orderCancle")
	@Transactional
	public String orderCancle(String orderId) {
		//�ֹ������ϻ���
		pservice.orderDetailsDelete(orderId);
		//�ֹ�����
		pservice.orderDelete(orderId);
		
		return "redirect:mypage";
	}
	




	
}
