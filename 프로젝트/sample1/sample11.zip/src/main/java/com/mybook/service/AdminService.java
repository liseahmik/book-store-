package com.mybook.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mybook.dto.CategoryDTO;
import com.mybook.dto.ProductDTO;
import com.mybook.repository.AdminRepository;

@Service
public class AdminService {
	@Autowired
	private AdminRepository adminRepository;
	
	//ī�װ���
	public List<CategoryDTO> category(){
		return adminRepository.category();
	}
	
	//��ǰ���
	public void productRegister(ProductDTO product) {
		adminRepository.productRegister(product);
	}
	
	//��ǰ ����
	public void productUpdate(ProductDTO product) {
		adminRepository. productUpdate(product);
	}
	
	
	//��ǰ ����
	public void productDelete(int productId) {
		adminRepository.productDelete(productId);
	}

	//�߼ۿϷ�
	public void shipped(String orderId) {
		adminRepository.shipped(orderId);		
	}
	
	//������߰�
	public void addTracking(HashMap<String, Object> hm) {
		adminRepository.addTracking(hm);
	}


}
