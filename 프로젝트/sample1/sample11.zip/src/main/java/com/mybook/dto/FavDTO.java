package com.mybook.dto;

import lombok.Data;

@Data
public class FavDTO {
	int favId;
	int productId;
	String userid;

}
