package com.mybook.repository;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mybook.dto.CartDTO;
import com.mybook.dto.CartListDTO;
import com.mybook.dto.FavDTO;
import com.mybook.dto.FavListDTO;
import com.mybook.dto.OrderDTO;
import com.mybook.dto.OrderDetailsDTO;
import com.mybook.dto.ProductCategoryDTO;
import com.mybook.dto.ProductDTO;
import com.mybook.dto.ReviewDTO;
import com.mybook.dto.orderProductDTO;
import com.mybook.mapper.ProductMapper;

@Repository
public class ProductRepository {
	@Autowired
	private ProductMapper productMapper;
	
	//��ǰ��ü��ȸ
	public List<ProductDTO> productAllList(HashMap<String, Object> hm){
		return productMapper.productAllList(hm);
	}

	//��ǰ��ȸ
	public List<ProductDTO> productList(HashMap<String, Object> hm){
		return productMapper.productList(hm);
	}
	
	//��ǰ �󼼺���
	public ProductDTO productView(int productId) {
		return productMapper.productView(productId);
	}
	
	//���� �ۼ�
	public void reviewRegister(ReviewDTO review) {
		productMapper.reviewRegister(review);
	}
	
	//���� ��ȸ
	public List<ReviewDTO> reviewList(HashMap<String, Object> hm){
		return productMapper.reviewList(hm);
	}

	//īƮ ���
	public void addCart(CartDTO cart) {
		productMapper.addCart(cart);		
	}

	//īƮ ����Ʈ
	public List<CartListDTO> cartList(String userid) {
		return productMapper.cartList(userid);
	}

	//īƮ ����
	public void cartDelete(CartDTO cart) {
		productMapper.cartDelete(cart);
		
	}

	public void addOrder(OrderDTO order) {
		productMapper.addOrder(order);		
	}

	public void addOrderDetails(OrderDetailsDTO orderDetails) {
		productMapper.addOrderDetails(orderDetails);		
	}

	public CartListDTO findByCartId(int cartId) {
		return productMapper.findByCartId(cartId);
	}

	public void cartAllDelete(String userid) {
		productMapper.cartAllDelete(userid);
		
	}

	public List<OrderDTO> orderList(String userid) {
		return productMapper.orderList(userid);
	}

	public List<OrderDTO> orderAllList(HashMap<String, Object> hm) {
		return productMapper.orderAllList(hm);
	}

	public OrderDTO orderView(String orderId) {
		return productMapper.orderView(orderId);
	}

	public List<orderProductDTO> orderProduct(String orderId) {
		return productMapper.orderProduct(orderId);
	}

	public int cartSize(String userid) {
		return productMapper.cartSize(userid);
	}

	public void cartDeleteOrder(HashMap<String, Object> hm) {
		productMapper.cartDeleteOrder(hm);
		
	}

	public void cartDelete2(CartDTO cart) {
		productMapper.cartDelete2(cart);
		
	}

	public void addFav(FavDTO fav) {
		productMapper.addFav(fav);
		
	}

	public List<FavListDTO> favList(String userid) {
		return productMapper.favList(userid);
	}

	public void favDelete(int favId) {
		productMapper.favDelete(favId);
		
	}

	public int findProductId(int cartId) {
		return productMapper.findProductId(cartId);
	}

	public void deleteReview(int reviewId) {
		productMapper.deleteReview(reviewId);
	}

	public int getOrderCount(HashMap<String, Object> hm) {
		return productMapper.getOrderCount(hm);
	}

	public int reviewCheck(ReviewDTO review) {
		return productMapper.reviewCheck(review);
	}

	public int cartCheck(CartDTO cart) {
		return productMapper.cartCheck(cart);
	}

	public int favCheck(FavDTO fav) {
		return productMapper.favCheck(fav);
	}

	public int[] getReviewStar(int productId) {
		return productMapper.getReviewStar(productId);
	}

	public int getReviewCount(int productId) {
		return productMapper.getReviewCount(productId);
	}

	public int getCategoryCount(String categoryCode) {
		return productMapper.getCategoryCount(categoryCode);
	}

	public int getProductAllCount(HashMap<String, Object> hm) {
		return productMapper.getProductAllCount(hm);
	}

	public String getOrderTitle(String orderId) {
		return productMapper.getOrderTitle(orderId);
	}

	public List<OrderDetailsDTO> getOrderDetails(String orderId) {
		return productMapper.getOrderDetails(orderId);
	}

	public void addSales(HashMap<String, Object> hm) {
		productMapper.addSales(hm);
		
	}

	public CartDTO getCart(int cartId) {
		return productMapper.getCart(cartId);
	}

	public void cartDeleteByCartId(int cartId) {
		productMapper.cartDeleteByCartId(cartId);
		
	}

	public List<ProductDTO> getBestSeller() {
		return productMapper.getBestSeller();
	}

	public List<ProductDTO> getLatestProducts() {
		return productMapper.getLatestProducts();
	}

	public ProductCategoryDTO productCategory(int productId) {
		return productMapper.productCategory(productId);
	}

	public int[] getTotalAmount(String userid) {
		return productMapper.getTotalAmount(userid);
	}

	public void orderDetailsDelete(String orderId) {
		productMapper.orderDetailsDelete(orderId);
		
	}

	public void orderDelete(String orderId) {
		productMapper.orderDelete(orderId);
		
	}


}
