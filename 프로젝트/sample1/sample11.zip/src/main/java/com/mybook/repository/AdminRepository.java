package com.mybook.repository;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mybook.dto.CategoryDTO;
import com.mybook.dto.ProductDTO;
import com.mybook.mapper.AdminMapper;
import com.mybook.mapper.MemberMapper;

@Repository
public class AdminRepository {
	@Autowired
	private AdminMapper adminMapper;
	
	//ī�װ���
	public List<CategoryDTO> category(){
		return adminMapper.category();
	}
	
	//��ǰ���
	public void productRegister(ProductDTO product) {
		adminMapper.productRegister(product);
	}
	
	//��ǰ ����
	public void productUpdate(ProductDTO product) {
		adminMapper. productUpdate(product);
	}
	
	//��ǰ ����
	public void productDelete(int productId) {
		adminMapper.productDelete(productId);
	}
	
	//�߼ۿϷ�
	public void shipped(String orderId) {
		adminMapper.shipped(orderId);		
	}

	//������߰�
	public void addTracking(HashMap<String, Object> hm) {
		adminMapper.addTracking(hm);
	}


}
