package com.mybook.mapper;

import java.util.HashMap;
import java.util.List;

import com.mybook.dto.QABoardDTO;
import com.mybook.dto.QACommentDTO;

public interface BoardMapper {

	public void insert(QABoardDTO board);

	public List<QABoardDTO> qnafindById(String userid);
	
	public QABoardDTO myqnaView(int boardId);

	public List<QABoardDTO> qnaAllList(HashMap<String, Object> hm);

	public void qnaComment(QACommentDTO comment);

	public void qnaReplied(int boardId);

	public QACommentDTO commentView(int boardId);

	public int qnaStatus(int boardId);

	public int getQnaCount(HashMap<String, Object> hm);

}
