package com.mybook.project;

import java.security.Principal;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.mybook.dto.MemberDTO;
import com.mybook.dto.OrderDTO;
import com.mybook.dto.PageDTO;
import com.mybook.dto.QABoardDTO;
import com.mybook.dto.QACommentDTO;
import com.mybook.mapper.BoardMapper;
import com.mybook.service.BoardService;
import com.mybook.service.MemberService;

@Controller
public class BoardController {
	@Autowired
	private BoardService bservice;
	
	@Autowired
	private MemberService mservice;
	
	@GetMapping("myqna")
	public String myqna(Principal principal,Model model) {
		String userid = principal.getName();
		MemberDTO member = mservice.findById(userid);
		model.addAttribute("member",member);
		
		List<QABoardDTO> list = bservice.qnafindById(userid);
		model.addAttribute("list",list);
		
		return "member/myqna";
	}
	
	@GetMapping("writeForm")
	public String writeForm(Principal principal,Model model) {
		String userid = principal.getName();
		MemberDTO member = mservice.findById(userid);
		model.addAttribute("member",member);
		return "member/qnaWrite";
	}
	
	@PostMapping("qnaRegister")
	public String insert(QABoardDTO board,Principal principal) {
		String userid = principal.getName();
		board.setUserid(userid);
				
		bservice.insert(board);
		return "redirect:myqna";
	}
	
	
	@GetMapping("myqnaView")
	public String myqnaView(int boardId,Principal principal,Model model) {
		String userid = principal.getName();
		MemberDTO member = mservice.findById(userid);
		model.addAttribute("member",member);
		
		QABoardDTO view = bservice.myqnaView(boardId);
		model.addAttribute("view",view);
		
		int status = bservice.qnaStatus(boardId);
		if(status == 1) {
			QACommentDTO comment = bservice.commentView(boardId);
			model.addAttribute("comment",comment);
		}
		
		return "member/myqnaView";
	}


}
