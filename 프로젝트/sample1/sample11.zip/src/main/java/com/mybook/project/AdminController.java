package com.mybook.project;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

import java.io.File;
import java.io.IOException;
import java.security.Principal;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.mybook.dto.CategoryDTO;
import com.mybook.dto.MemberDTO;
import com.mybook.dto.OrderDTO;
import com.mybook.dto.OrderDetailsDTO;
import com.mybook.dto.PageDTO;
import com.mybook.dto.ProductCategoryDTO;
import com.mybook.dto.ProductDTO;
import com.mybook.dto.QABoardDTO;
import com.mybook.dto.QACommentDTO;
import com.mybook.dto.orderProductDTO;
import com.mybook.service.AdminService;
import com.mybook.service.BoardService;
import com.mybook.service.MemberService;
import com.mybook.service.ProductService;

import net.sf.json.JSONArray;

@Controller
public class AdminController {
	@Autowired
	private MemberService mservice;
	
	@Autowired
	private AdminService aservice;
	
	@Autowired
	private ProductService pservice;
	
	@Autowired
	private BoardService bservice;
	
	
	//��ǰ��� ������
	@GetMapping("productRegister")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String productRegister(Model model) {
		List<CategoryDTO> category = aservice.category();
		model.addAttribute("category", JSONArray.fromObject(category));
		return "admin/product/register";
	}
	

	//��ǰ���
	@PostMapping("productRegister")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String productRegister(ProductDTO product, HttpServletRequest request) throws IOException {
		String saveDir = request.getSession().getServletContext().getRealPath("/");
		saveDir += "resources\\product_img\\";
		MultipartFile f = product.getUploadFile();
		String fileName="";
		if(!f.isEmpty()) {
			String orifileName = f.getOriginalFilename();
			System.out.println("getOriginalFilename:"+orifileName);
			//���ϸ� ����
			UUID uuid = UUID.randomUUID();
			fileName = uuid+"_"+orifileName;
			FileCopyUtils.copy(f.getBytes(), new File(saveDir+fileName));
			product.setProductImg(fileName);
		}
		
		System.out.println("saveDir:"+saveDir);
		aservice.productRegister(product);
		return "redirect:productAllList";
	}
	

	//ȸ�� ����Ʈ
	@GetMapping("userList")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String userList(Model model, String field, String word, String strPageNum) {
		
		strPageNum = (strPageNum == null) ? "1" : strPageNum ;
		int pageNum = Integer.parseInt(strPageNum);
		HashMap<String, Object> hm = new HashMap<>();
		hm.put("field",field);
		hm.put("word",word);
		
		int totalCount = mservice.getCount(hm);
		int pageSize= 5;
		int pageBlock= 10;
		int pageCount = (int) Math.ceil((double) totalCount / pageSize);
		int startPage = ((pageNum / pageBlock) - (pageNum % pageBlock == 0 ? 1 : 0)) * pageBlock + 1;
		int endPage = startPage + pageBlock - 1;
		if(endPage > pageCount) {
			endPage = pageCount;
		}
		PageDTO pageDto = new PageDTO();
		pageDto.setPageCount(pageCount);
		pageDto.setPageBlock(pageBlock);
		pageDto.setStartPage(startPage);
		pageDto.setEndPage(endPage);
		pageDto.setTotalCount(totalCount);
		pageDto.setPageNum(pageNum);
		
		int startRow =(pageNum-1)*pageSize;
		hm.put("startRow",startRow);
		hm.put("pageSize", pageSize);
		List<MemberDTO> list = mservice.findAll(hm);
		
		model.addAttribute("userList",list);
		model.addAttribute("count",totalCount);
		model.addAttribute("pageDto",pageDto);
		model.addAttribute("field",field);
		model.addAttribute("word",word);

		return "admin/member/userList";
	}
	
	
	//��ǰ ����������
	@GetMapping("productUpdateForm")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String productUpdateForm(int productId, Model model) {
		ProductCategoryDTO product = pservice.productCategory(productId);
		model.addAttribute("product",product);
		List<CategoryDTO> category = aservice.category();
		model.addAttribute("category", JSONArray.fromObject(category));
		return "admin/product/updateForm";
	}
	
	

	//��ǰ ����(+�̹�������)
	@PostMapping("productUpdate")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String productUpdate(ProductDTO product, HttpServletRequest request) {
		String saveDir = request.getSession().getServletContext().getRealPath("/");
		saveDir += "resources\\product_img\\";
		MultipartFile f = product.getUploadFile();
		String fileName="";
		
		// ���ο� ������ ��ϵǾ����� Ȯ��
		if(!f.isEmpty()) {
		  // ���� ������ ����
			new File(saveDir + request.getParameter("productImg")).delete();
		  
		  // ���� ÷���� ������ ���
		  	String orifileName = f.getOriginalFilename();
			System.out.println("getOriginalFilename:"+orifileName);
			//���ϸ� ����
			UUID uuid = UUID.randomUUID();
			fileName = uuid+"_"+orifileName;
			try {
				FileCopyUtils.copy(f.getBytes(), new File(saveDir+fileName));
			} catch (IOException e) {
				e.printStackTrace();
			}
			product.setProductImg(fileName);
		  
		 } else {  // ���ο� ������ ��ϵ��� �ʾҴٸ�
		  // ���� �̹����� �״�� ���
		  product.setProductImg(request.getParameter("productImg"));
		 }
		
		aservice.productUpdate(product);
		return "redirect:productAllList";
	}
	

	//��ǰ ����
	@GetMapping("productDelete")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String productDelete(int productId, HttpServletRequest request) {
		String saveDir = request.getSession().getServletContext().getRealPath("/");
		saveDir += "resources\\product_img\\";
		
		ProductDTO p= pservice.productView(productId);
		String f = "";
		f =	p.getProductImg();
	
		if(f!=null) {
			new File(saveDir + f).delete();
		}
		
		aservice.productDelete(productId);
		return "redirect:productAllList";
	}
	

	//�ֹ� ��ü ����Ʈ
	@GetMapping("orderList")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String orderAllList(Model model,String field, String word, String strPageNum) {
		strPageNum = (strPageNum == null) ? "1" : strPageNum ;
		int pageNum = Integer.parseInt(strPageNum);
		HashMap<String, Object> hm = new HashMap<>();
		hm.put("field",field);
		hm.put("word",word);
		
		int totalCount = pservice.getOrderCount(hm);
		int pageSize= 5;
		int pageBlock= 10;
		int pageCount = (int) Math.ceil((double) totalCount / pageSize);
		int startPage = ((pageNum / pageBlock) - (pageNum % pageBlock == 0 ? 1 : 0)) * pageBlock + 1;
		int endPage = startPage + pageBlock - 1;
		if(endPage > pageCount) {
			endPage = pageCount;
		}
		PageDTO pageDto = new PageDTO();
		pageDto.setPageCount(pageCount);
		pageDto.setPageBlock(pageBlock);
		pageDto.setStartPage(startPage);
		pageDto.setEndPage(endPage);
		pageDto.setTotalCount(totalCount);
		pageDto.setPageNum(pageNum);
		
		int startRow =(pageNum-1)*pageSize;
		hm.put("startRow",startRow);
		hm.put("pageSize", pageSize);
		List<OrderDTO> list = pservice.orderAllList(hm);
		
		model.addAttribute("list",list);
		model.addAttribute("count",totalCount);
		model.addAttribute("pageDto",pageDto);
		model.addAttribute("field",field);
		model.addAttribute("word",word);

		return "admin/product/orderList";
	}
	

	//�ֹ� �󼼺���
	@GetMapping("orderView")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String orderView(String orderId, Model model) {
		OrderDTO order = pservice.orderView(orderId);
		model.addAttribute("order",order);
		List<orderProductDTO> orderProduct = pservice.orderProduct(orderId);
		model.addAttribute("orderProduct",orderProduct);
		return "admin/product/orderView";
	}
	
	
	//�ֹ� ���º���
	@PostMapping("orderUpdate")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String orderUpdate(String orderId, String tracking) {
		HashMap<String, Object> hm = new HashMap<>();
		hm.put("orderId",orderId);
		hm.put("tracking",tracking);
		aservice.addTracking(hm);
		aservice.shipped(orderId);
		
		AddSales(orderId); //test
		
		return "redirect:orderList";
	}
	
	
	//QNA ����Ʈ(������) 
	@GetMapping("qnaList")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String qnaList(Model model, String field, String word, String strPageNum) {
		
		strPageNum = (strPageNum == null) ? "1" : strPageNum ;
		int pageNum = Integer.parseInt(strPageNum);
		HashMap<String, Object> hm = new HashMap<>();
		hm.put("field",field);
		hm.put("word",word);
		
		int totalCount = bservice.getQnaCount(hm);
		int pageSize= 5;
		int pageBlock= 10;
		int pageCount = (int) Math.ceil((double) totalCount / pageSize);
		int startPage = ((pageNum / pageBlock) - (pageNum % pageBlock == 0 ? 1 : 0)) * pageBlock + 1;
		int endPage = startPage + pageBlock - 1;
		if(endPage > pageCount) {
			endPage = pageCount;
		}
		PageDTO pageDto = new PageDTO();
		pageDto.setPageCount(pageCount);
		pageDto.setPageBlock(pageBlock);
		pageDto.setStartPage(startPage);
		pageDto.setEndPage(endPage);
		pageDto.setTotalCount(totalCount);
		pageDto.setPageNum(pageNum);
		
		int startRow =(pageNum-1)*pageSize;
		hm.put("startRow",startRow);
		hm.put("pageSize", pageSize);
		List<QABoardDTO> list = bservice.qnaAllList(hm);
		
		model.addAttribute("list",list);
		model.addAttribute("count",totalCount);
		model.addAttribute("pageDto",pageDto);
		model.addAttribute("field",field);
		model.addAttribute("word",word);
		

		return "admin/board/qnaList";
	}
	
	
	//QNA �󼼺���(������)
	@GetMapping("qnaViewAdmin")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String qnaViewAdmin(int boardId,Model model) {
		QABoardDTO view = bservice.myqnaView(boardId);
		model.addAttribute("view",view);
		
		int status = bservice.qnaStatus(boardId);
		if(status == 1) {
			QACommentDTO comment = bservice.commentView(boardId);
			model.addAttribute("comment",comment);
		}
		return "admin/board/qnaViewAdmin";
	}


	//QNA ���
	@PostMapping("comment")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String qnaComment(QACommentDTO comment) {
		System.out.println(comment);
		bservice.qnaComment(comment);
		//���º���
		int boardId = comment.getBoardId();
		bservice.qnaReplied(boardId);
		return "redirect:qnaList";
	}
	
	
	//��ۿϷ� �� �Ǹŷ� ����
	public void AddSales(String orderId) {
		List<OrderDetailsDTO> list = pservice.getOrderDetails(orderId);
		System.out.println(list);

		HashMap<String, Object> hm = new HashMap<>();
		for(OrderDetailsDTO details : list) {
			hm.put("productId",details.getProductId());
			hm.put("qty",details.getQty());
			pservice.addSales(hm);
		}

	}
	
	
	//������� //�ϰ�
	@GetMapping("gradeAllChange")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String GradeAllChange() {
		String[] users = mservice.getUserid();
		for(int i=0; i<users.length; i++) {
			GradeChange(users[i]);
		}
		return "redirect:userList";
	}
	
	
	//������� //���� 
	public void GradeChange(String userid) {
		int total = 0;
		int[] arr = pservice.getTotalAmount(userid);
		System.out.println(arr);
		
		for(int i=0; i<arr.length; i++) {
			if (arr[i]<22000) total += arr[i]-2000;
			if (arr[i]>=22000) total += arr[i];
		}
		System.out.println(total);
		
		if(total<100000) {
			mservice.setBronze(userid);
		}else if(total<200000) {
			mservice.setSilver(userid);
		}else if(total<500000) {
			mservice.setGold(userid);
		}else {
			mservice.setPlatinum(userid);
		}
	}
	

}
