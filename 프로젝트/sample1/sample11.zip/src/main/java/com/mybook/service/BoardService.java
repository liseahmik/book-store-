package com.mybook.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mybook.dto.QABoardDTO;
import com.mybook.dto.QACommentDTO;
import com.mybook.repository.BoardRepository;

@Service
public class BoardService {
	@Autowired
	private BoardRepository boardRepository;

	public void insert(QABoardDTO board) {
		boardRepository.insert(board);
		
	}

	public List<QABoardDTO> qnafindById(String userid) {
		return boardRepository.qnafindById(userid);
	}
	
	public QABoardDTO myqnaView(int boardId) {
		return boardRepository.myqnaView(boardId);
	}

	public List<QABoardDTO> qnaAllList(HashMap<String, Object> hm) {
		return boardRepository.qnaAllList(hm);
	}

	public void qnaComment(QACommentDTO comment) {
		boardRepository.qnaComment(comment);
		
	}

	public void qnaReplied(int boardId) {
		boardRepository.qnaReplied(boardId);
		
	}

	public QACommentDTO commentView(int boardId) {
		return boardRepository.commentView(boardId);
	}

	public int qnaStatus(int boardId) {
		return boardRepository.qnaStatus(boardId);
	}

	public int getQnaCount(HashMap<String, Object> hm) {
		return boardRepository.getQnaCount(hm);
	}

}
