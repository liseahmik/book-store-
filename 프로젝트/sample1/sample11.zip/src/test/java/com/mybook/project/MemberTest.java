package com.mybook.project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({
	"file:src/main/webapp/WEB-INF/spring/root-context.xml",
	"file:src/main/webapp/WEB-INF/spring/security-context.xml"
})

public class MemberTest {
	@Autowired
	private PasswordEncoder pwencoder;
	@Autowired
	private DataSource ds;
	
	@Test
	public void testinsertMember() {
		String sql ="insert into users(userid,userpass,username) values(?,?,?)";
		for(int i=0; i<100; i++) {
			Connection con = null;
			PreparedStatement ps = null;
			
			try {
				con = ds.getConnection();
				ps = con.prepareStatement(sql);
				
				ps.setString(2, pwencoder.encode("pw"+i));
				if(i<80) {
					ps.setString(1,"user"+i);
					ps.setString(3, "ȸ��"+i);
				}else if(i<90) {
					ps.setString(1, "manager"+i);
					ps.setString(3, "���"+i);					
				}else {
					ps.setString(1, "admin"+i);
					ps.setString(3, "������"+i);
				}
				ps.executeUpdate();
			}catch(SQLException e) {
				e.printStackTrace();
			}finally {
				if(ps!=null) {try {ps.close();} catch(Exception e) {} }
				if(con!=null) {try {con.close();} catch(Exception e) {} }
			}
			
		}
	}//testinsertMember
	
	@Test
	public void testInsertAuth() {
		String sql="insert into auth(userid,auth) values(?,?)";
		
		for(int i=0; i<100; i++) {
			Connection con = null;
			PreparedStatement ps = null;
			
			try {
				con = ds.getConnection();
				ps = con.prepareStatement(sql);

				if(i<80) {
					ps.setString(1,"user"+i);
					ps.setString(2, "ROLE_USER");
				}else if(i<90) {
					ps.setString(1, "manager"+i);
					ps.setString(2, "ROLE_MANAGER");					
				}else {
					ps.setString(1, "admin"+i);
					ps.setString(2, "ROLE_ADMIN");
				}
				ps.executeUpdate();
			}catch(SQLException e) {
				e.printStackTrace();
			}finally {
				if(ps!=null) {try {ps.close();} catch(Exception e) {} }
				if(con!=null) {try {con.close();} catch(Exception e) {} }
			}
			
		}
	}//testInsertAuth
	

}
